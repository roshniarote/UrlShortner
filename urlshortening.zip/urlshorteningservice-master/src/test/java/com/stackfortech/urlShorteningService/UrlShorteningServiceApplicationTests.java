package com.stackfortech.urlShorteningService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlShorteningServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
